"""
统计应力反演 - ILSI版本
用于噪声数据的不确定性分析
"""

import numpy as np
import sys

def statistics_stress_inversion_ilsi(strike1, dip1, rake1, strike2, dip2, rake2,
                                     friction, N_iterations, N_realizations,
                                     use_variable_shear=True):
    """
    使用ILSI方法进行统计应力反演
    
    Parameters:
    -----------
    strike1, dip1, rake1 : 第一组节面参数
    strike2, dip2, rake2 : 第二组节面参数  
    friction : 摩擦系数
    N_iterations : 迭代次数
    N_realizations : 实现次数
    use_variable_shear : 是否使用变剪切应力（ILSI特性）
    
    Returns:
    --------
    sigma_vector_1, sigma_vector_2, sigma_vector_3 : 主应力方向
    shape_ratio : 形状比
    """
    import stress_inversion as si_original
    from stress_inversion_ilsi_module import (
        iterative_linear_si,
        compute_instability_parameter,
        stress_tensor_eigendecomposition
    )
    
    # 初始应力估计（使用多次随机选择）
    tau = np.zeros((3, 3))
    for i_realization in range(N_realizations):
        tau_realization = si_original.linear_stress_inversion_Michael(
            strike1, dip1, rake1, strike2, dip2, rake2)
        tau = tau + tau_realization
    
    tau0 = tau / np.linalg.norm(tau, 'fro')
    
    # 迭代优化
    norm_difference_tau = np.zeros(N_iterations)
    
    for i_iteration in range(N_iterations):
        # 计算主应力方向和形状比
        principal_stresses, principal_directions = stress_tensor_eigendecomposition(tau0)
        R = (principal_stresses[0] - principal_stresses[1]) / (principal_stresses[0] - principal_stresses[2])
        
        # 使用不稳定性准则选择节面
        instability, strike, dip, rake = compute_instability_parameter(
            principal_directions, R, friction,
            strike1, dip1, rake1, strike2, dip2, rake2,
            return_fault_planes=True, signed_instability=False
        )
        
        if use_variable_shear:
            # 使用ILSI方法（允许变剪切应力）
            output = iterative_linear_si(
                strike, dip, rake,
                max_n_iterations=300,
                shear_update_atol=1e-5,
                return_eigen=False,
                return_stats=False
            )
            tau = output["stress_tensor"]
        else:
            # 使用传统Michael方法（固定剪切应力）
            tau = si_original.linear_stress_inversion(strike, dip, rake)
        
        # 归一化
        norm = np.linalg.norm(tau, 'fro')
        if norm > 0:
            tau /= norm
        
        # 检查收敛性
        norm_difference_tau[i_iteration] = np.linalg.norm(tau - tau0, 'fro')
        tau0 = tau
    
    # 最终应力张量的特征分解
    diag_tensor, vector = np.linalg.eig(tau)
    
    value = np.linalg.eigvals(np.diag(diag_tensor))
    value_sorted = np.sort(value)
    j = np.argsort(value)
    
    sigma_vector_1 = np.array(vector[:, j[0]])
    sigma_vector_2 = np.array(vector[:, j[1]])
    sigma_vector_3 = np.array(vector[:, j[2]])
    
    # 确保向上为正
    if sigma_vector_1[2] < 0: 
        sigma_vector_1 = -sigma_vector_1
    if sigma_vector_2[2] < 0: 
        sigma_vector_2 = -sigma_vector_2
    if sigma_vector_3[2] < 0: 
        sigma_vector_3 = -sigma_vector_3
    
    # 计算形状比
    sigma = np.sort(np.linalg.eigvals(tau))
    shape_ratio = (sigma[0] - sigma[1]) / (sigma[0] - sigma[2])
    
    return sigma_vector_1, sigma_vector_2, sigma_vector_3, shape_ratio