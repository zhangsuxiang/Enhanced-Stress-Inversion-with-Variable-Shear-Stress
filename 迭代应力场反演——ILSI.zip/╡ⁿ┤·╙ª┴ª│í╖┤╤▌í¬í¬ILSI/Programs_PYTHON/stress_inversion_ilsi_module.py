"""
ILSI应力反演模块 - 完整科研版
基于Beauce et al. 2022的完整实现
"""

import sys
import numpy as np
import warnings
from functools import partial
from numpy.linalg import LinAlgError

def forward_model(n_):
    """
    构建前向模型矩阵G
    基于断层法向量集合
    
    Parameters:
    -----------
    n_: (n_earthquakes, 3) numpy.ndarray
        第i行是第i个断层的法向量，在(north, east, down)坐标系中
    
    Returns:
    --------
    G: (3 x n_earthquakes, 5) numpy.ndarray
        前向模型矩阵
    """
    n_earthquakes = n_.shape[0]
    G = np.zeros((n_earthquakes * 3, 5), dtype=np.float32)
    for i in range(n_earthquakes):
        ii = i * 3
        n1, n2, n3 = n_[i, :]
        G[ii + 0, 0] = n1 + n1 * n3**2 - n1**3
        G[ii + 0, 1] = n2 - 2.0 * n2 * n1**2
        G[ii + 0, 2] = n3 - 2.0 * n3 * n1**2
        G[ii + 0, 3] = n1 * n3**2 - n1 * n2**2
        G[ii + 0, 4] = -2.0 * n1 * n2 * n3
        G[ii + 1, 0] = n2 * n3**2 - n2 * n1**2
        G[ii + 1, 1] = n1 - 2.0 * n1 * n2**2
        G[ii + 1, 2] = -2.0 * n1 * n2 * n3
        G[ii + 1, 3] = n2 + n2 * n3**2 - n2**3
        G[ii + 1, 4] = n3 - 2.0 * n3 * n2**2
        G[ii + 2, 0] = n3**3 - n3 - n3 * n1**2
        G[ii + 2, 1] = -2.0 * n1 * n2 * n3
        G[ii + 2, 2] = n1 - 2.0 * n1 * n3**2
        G[ii + 2, 3] = n3**3 - n3 - n3 * n2**2
        G[ii + 2, 4] = n2 - 2.0 * n2 * n3**2
    return G

def normal_slip_vectors(strike, dip, rake, direction="inward"):
    """
    计算震源机制的法向量和滑动向量
    
    坐标系 (x1, x2, x3):
    x1: north
    x2: east
    x3: down
    """
    d2r = np.pi / 180.0
    strike = strike * d2r
    dip = dip * d2r
    rake = rake * d2r
    
    # 法向量（footwall的外法向量）
    n = np.array([
        -np.sin(dip) * np.sin(strike),   # North分量
        np.sin(dip) * np.cos(strike),     # East分量
        -np.cos(dip)                      # Down分量
    ])
    
    if direction == "outward":
        n *= -1.0
    
    # 滑动向量（hanging wall相对于foot wall的运动）
    d = np.array([
        np.cos(rake) * np.cos(strike) + np.sin(rake) * np.cos(dip) * np.sin(strike),
        np.cos(rake) * np.sin(strike) - np.sin(rake) * np.cos(dip) * np.cos(strike),
        -np.sin(rake) * np.sin(dip)
    ])
    
    return n, d

def iterative_linear_si(
    strikes,
    dips,
    rakes,
    max_n_iterations=300,
    shear_update_atol=1.0e-5,
    Tarantola_kwargs=None,
    return_eigen=True,
    return_stats=False,
):
    """
    迭代应力反演 - Beauce et al. 2022
    
    假设:
    - 构造应力场是均匀的
    - Wallace-Bott假设：滑动向量与断层上的剪切应力方向相同
    
    Parameters:
    -----------
    strikes, dips, rakes: 震源机制参数
    max_n_iterations: 最大迭代次数
    shear_update_atol: 剪切应力收敛阈值
    Tarantola_kwargs: Tarantola-Valette反演参数
    return_eigen: 是否返回特征分解
    return_stats: 是否返回统计信息
    
    Returns:
    --------
    output: dict 包含反演结果
    """
    # 转换strike/dip/rake为滑动和法向量
    n_earthquakes = len(strikes)
    n_ = np.zeros((n_earthquakes, 3), dtype=np.float32)
    d_ = np.zeros((n_earthquakes, 3), dtype=np.float32)
    
    for i in range(n_earthquakes):
        n_[i, :], d_[i, :] = normal_slip_vectors(strikes[i], dips[i], rakes[i], direction="inward")
    
    # 构建前向模型矩阵
    G = forward_model(n_)
    
    if Tarantola_kwargs is not None:
        method = "tarantola"
        Tarantola_kwargs = Tarantola_kwargs.copy()
    else:
        method = "moore_penrose"
    
    # 初始化剪切应力幅值
    if method == "tarantola" and "m_prior" in Tarantola_kwargs:
        if Tarantola_kwargs["m_prior"].sum() != 0.:
            shear = np.sqrt(
                np.sum(
                    (G @ Tarantola_kwargs["m_prior"].astype("float32")).reshape(
                        n_earthquakes, 3
                    ) ** 2,
                    axis=-1,
                )
            )
        else:
            shear = np.ones(n_earthquakes, dtype=np.float32)
    else:
        shear = np.ones(n_earthquakes, dtype=np.float32)
    
    # 迭代优化
    for j in range(max_n_iterations):
        if method == "tarantola":
            sigma, C_m_posterior, C_d_posterior = Tarantola_Valette(
                G, d_ * shear[:, np.newaxis], **Tarantola_kwargs
            )
            sigma = sigma.squeeze()
        elif method == "moore_penrose":
            G_pinv = np.linalg.pinv(G)
            sigma = np.dot(G_pinv, (d_ * shear[:, np.newaxis]).reshape(-1, 1)).squeeze()
        
        # 归一化应力张量
        full_stress_tensor = np.array([
            [sigma[0], sigma[1], sigma[2]],
            [sigma[1], sigma[3], sigma[4]],
            [sigma[2], sigma[4], -sigma[0] - sigma[3]],
        ])
        
        # 按迹归一化
        norm = np.sqrt(np.sum(np.diag(full_stress_tensor)**2))
        norm = 1 if norm == 0.0 else norm
        sigma /= norm
        
        if method == "tarantola":
            Tarantola_kwargs["m_prior"] = sigma.reshape(5, 1).copy()
        
        # 计算剪切应力幅值
        shear0 = shear.copy()
        predicted_shear = (G @ sigma).reshape(n_earthquakes, 3)
        shear = np.sqrt(np.sum(predicted_shear**2, axis=-1))
        shear_update = np.sqrt(np.mean((shear - shear0) ** 2))
        
        if shear_update < shear_update_atol:
            break
    
    # 构建完整应力张量
    sigma = sigma.squeeze()
    full_stress_tensor = np.array([
        [sigma[0], sigma[1], sigma[2]],
        [sigma[1], sigma[3], sigma[4]],
        [sigma[2], sigma[4], -sigma[0] - sigma[3]],
    ])
    
    # 最终归一化
    norm = np.sqrt(np.sum(full_stress_tensor**2))
    norm = 1 if norm == 0.0 else norm
    full_stress_tensor /= norm
    
    # 返回结果
    output = {}
    output["stress_tensor"] = full_stress_tensor
    output["predicted_shear_stress"] = predicted_shear
    
    if return_eigen:
        principal_stresses, principal_directions = stress_tensor_eigendecomposition(full_stress_tensor)
        output["shear_stress_magnitudes"] = shear
        output["principal_stresses"] = principal_stresses
        output["principal_directions"] = principal_directions
    
    if return_stats and method == "tarantola":
        C_m_posterior /= norm**2
        output["C_d_posterior"] = C_d_posterior
        output["C_m_posterior"] = C_m_posterior
    
    return output

def Tarantola_Valette(
    G,
    data,
    C_d=None,
    C_d_inv=None,
    C_m=None,
    C_m_inv=None,
    m_prior=None,
    inversion_space="model_space",
):
    """
    Tarantola和Valette的最小二乘解
    """
    dim_D = G.shape[0]
    dim_M = G.shape[1]
    
    # 处理协方差矩阵
    if C_d is None:
        C_d = np.zeros((dim_D, dim_D), dtype=np.float32)
        C_d_inv = np.identity(dim_D, dtype=np.float32)
    elif C_d_inv is None and inversion_space == "model_space":
        try:
            C_d_inv = np.linalg.inv(C_d)
        except LinAlgError:
            print("Cannot invert data covariance matrix")
            sys.exit()
    
    if C_m is None:
        C_m = np.identity(dim_M, dtype=np.float32)
        C_m_inv = np.zeros_like(C_m)
    elif C_m_inv is None and inversion_space == "model_space":
        try:
            C_m_inv = np.linalg.inv(C_m)
        except LinAlgError:
            print("Cannot invert model covariance matrix")
            sys.exit()
    
    if m_prior is None:
        m_prior = np.zeros((dim_M, 1), dtype=np.float32)
    
    # 确保data是列向量
    data = data.reshape(-1, 1)
    
    if inversion_space == "data_space":
        # 在数据空间反演
        Cm_Gt = C_m.dot(G.T)
        inv = np.linalg.inv(G.dot(Cm_Gt) + C_d)
        Cm_Gt_inv = Cm_Gt.dot(inv)
        m_inv = m_prior + np.dot(Cm_Gt_inv, data - np.dot(G, m_prior))
        C_m_posterior = C_m - (Cm_Gt_inv.dot(G)).dot(C_m)
    elif inversion_space == "model_space":
        # 在模型空间反演
        Gt_Cdinv = G.T.dot(C_d_inv)
        try:
            inv = np.linalg.inv(Gt_Cdinv.dot(G) + C_m_inv)
        except LinAlgError:
            print("Could not solve the inverse problem in the model space.")
            sys.exit()
        m_inv = m_prior + (inv.dot(Gt_Cdinv)).dot(data - G.dot(m_prior))
        C_m_posterior = inv.copy()
    else:
        print('inversion_space should be either "model_space" or "data_space"')
        return
    
    C_d_posterior = (G.dot(C_m_posterior)).dot(G.T)
    
    return m_inv, C_m_posterior, C_d_posterior

def stress_tensor_eigendecomposition(stress_tensor):
    """计算应力张量的特征分解"""
    try:
        principal_stresses, principal_directions = np.linalg.eigh(stress_tensor)
    except LinAlgError:
        print("Eigendecomposition failed")
        sys.exit()
    
    order = np.argsort(principal_stresses)
    principal_stresses = principal_stresses[order]
    principal_directions = principal_directions[:, order]
    
    # 确保右手坐标系
    principal_directions = check_right_handedness(principal_directions)
    
    return principal_stresses, principal_directions

def check_right_handedness(basis):
    """确保列向量矩阵构成右手坐标系"""
    vector1 = basis[:, 0]
    vector2 = basis[:, 1]
    vector3 = np.cross(vector1, vector2)
    return np.stack([vector1, vector2, vector3], axis=1)

def Michael1984_inversion(
    strikes, dips, rakes, Tarantola_kwargs=None, return_eigen=True, return_stats=False
):
    """
    Michael 1984线性反演
    假设所有断层上剪切应力恒定
    """
    n_earthquakes = len(strikes)
    n_ = np.zeros((n_earthquakes, 3), dtype=np.float32)
    d_ = np.zeros((n_earthquakes, 3), dtype=np.float32)
    
    for i in range(n_earthquakes):
        n_[i, :], d_[i, :] = normal_slip_vectors(strikes[i], dips[i], rakes[i], direction="inward")
    
    G = forward_model(n_)
    
    if Tarantola_kwargs is not None:
        sigma, C_m_posterior, C_d_posterior = Tarantola_Valette(G, d_, **Tarantola_kwargs)
        sigma = sigma.squeeze()
        method = "tarantola"
    else:
        G_pinv = np.linalg.pinv(G)
        sigma = np.dot(G_pinv, d_.reshape(-1, 1)).squeeze()
        method = "moore_penrose"
    
    full_stress_tensor = np.array([
        [sigma[0], sigma[1], sigma[2]],
        [sigma[1], sigma[3], sigma[4]],
        [sigma[2], sigma[4], -sigma[0] - sigma[3]],
    ])
    
    norm = np.sqrt(np.sum(full_stress_tensor**2))
    norm = 1 if norm == 0.0 else norm
    full_stress_tensor /= norm
    
    output = {}
    output["stress_tensor"] = full_stress_tensor
    output["predicted_shear_stress"] = (G @ sigma).reshape(n_earthquakes, 3)
    
    if return_eigen:
        principal_stresses, principal_directions = stress_tensor_eigendecomposition(full_stress_tensor)
        output["principal_stresses"] = principal_stresses
        output["principal_directions"] = principal_directions
    
    if return_stats and method == "tarantola":
        C_m_posterior /= norm**2
        output["C_d_posterior"] = C_d_posterior
        output["C_m_posterior"] = C_m_posterior
    
    return output

def compute_instability_parameter(
    principal_directions,
    R,
    friction,
    strike_1,
    dip_1,
    rake_1,
    strike_2,
    dip_2,
    rake_2,
    return_fault_planes=False,
    signed_instability=False,
):
    """
    计算不稳定性参数
    基于Lund and Slunga 1999, Vavrycuk 2013-2014
    """
    n_earthquakes = len(strike_1)
    n_1 = np.zeros((n_earthquakes, 3), dtype=np.float32)
    n_2 = np.zeros((n_earthquakes, 3), dtype=np.float32)
    d_1 = np.zeros((n_earthquakes, 3), dtype=np.float32)
    d_2 = np.zeros((n_earthquakes, 3), dtype=np.float32)
    
    # 计算两个节面的法向量
    for i in range(n_earthquakes):
        n_1[i, :], d_1[i, :] = normal_slip_vectors(strike_1[i], dip_1[i], rake_1[i], direction="inward")
        n_2[i, :], d_2[i, :] = normal_slip_vectors(strike_2[i], dip_2[i], rake_2[i], direction="inward")
    
    # 投影到主应力基
    n_1 = np.dot(n_1, principal_directions)
    n_2 = np.dot(n_2, principal_directions)
    d_1 = np.dot(d_1, principal_directions)
    d_2 = np.dot(d_2, principal_directions)
    
    # 应力张量参数化
    sig1 = -1.0
    sig2 = 2.0 * R - 1.0
    sig3 = +1.0
    tau_c = 1.0 / np.sqrt(1.0 + friction**2)
    sig_c = friction / np.sqrt(1.0 + friction**2)
    
    # 计算剪切和法向应力
    normal_1 = sig1 * n_1[:, 0]**2 + sig2 * n_1[:, 1]**2 + sig3 * n_1[:, 2]**2
    shear_1 = np.sqrt(
        sig1**2 * n_1[:, 0]**2 + sig2**2 * n_1[:, 1]**2 + sig3**2 * n_1[:, 2]**2 - normal_1**2
    )
    
    normal_2 = sig1 * n_2[:, 0]**2 + sig2 * n_2[:, 1]**2 + sig3 * n_2[:, 2]**2
    shear_2 = np.sqrt(
        sig1**2 * n_2[:, 0]**2 + sig2**2 * n_2[:, 1]**2 + sig3**2 * n_2[:, 2]**2 - normal_2**2
    )
    
    # 计算不稳定性参数
    Ic = tau_c - friction * (sig1 - sig_c)
    I_1 = (shear_1 - friction * (sig1 - normal_1)) / Ic
    I_2 = (shear_2 - friction * (sig1 - normal_2)) / Ic
    
    if signed_instability:
        # 计算剪切-滑动方向的符号
        stress_tensor = np.diag([sig1, sig2, sig3])
        traction_1_vec = np.dot(stress_tensor, n_1.T).T
        traction_2_vec = np.dot(stress_tensor, n_2.T).T
        normal_1_vec = np.sum(traction_1_vec * n_1, axis=-1)[:, np.newaxis] * n_1
        normal_2_vec = np.sum(traction_2_vec * n_2, axis=-1)[:, np.newaxis] * n_2
        shear_1_vec = traction_1_vec - normal_1_vec
        shear_2_vec = traction_2_vec - normal_2_vec
        sign_dot_1 = np.sign(np.sum(shear_1_vec * d_1, axis=-1))
        sign_dot_2 = np.sign(np.sum(shear_2_vec * d_2, axis=-1))
        I_1 *= sign_dot_1
        I_2 *= sign_dot_2
    
    if return_fault_planes:
        strikes = np.zeros(n_earthquakes, dtype=np.float32)
        dips = np.zeros(n_earthquakes, dtype=np.float32)
        rakes = np.zeros(n_earthquakes, dtype=np.float32)
        mask_1 = I_1 >= I_2
        strikes[mask_1] = strike_1[mask_1]
        dips[mask_1] = dip_1[mask_1]
        rakes[mask_1] = rake_1[mask_1]
        mask_2 = ~mask_1
        strikes[mask_2] = strike_2[mask_2]
        dips[mask_2] = dip_2[mask_2]
        rakes[mask_2] = rake_2[mask_2]
        return np.column_stack((I_1, I_2)), strikes, dips, rakes
    else:
        return np.column_stack((I_1, I_2))

def stress_inversion_ilsi(strike1, dip1, rake1, strike2, dip2, rake2,
                          friction_min, friction_max, friction_step,
                          N_iterations, N_realizations,
                          use_variable_shear=True,
                          max_shear_iterations=300,
                          shear_tolerance=1e-5):
    """
    完整的ILSI应力反演实现
    """
    import stress_inversion as si_original
    
    # 初始应力估计
    tau = np.zeros((3, 3))
    for i_realization in range(N_realizations):
        tau_realization = si_original.linear_stress_inversion_Michael(
            strike1, dip1, rake1, strike2, dip2, rake2)
        tau = tau + tau_realization
    
    tau0 = tau / np.linalg.norm(tau, 'fro')
    
    # 计算初始主应力
    principal_stresses, principal_directions = stress_tensor_eigendecomposition(tau0)
    R_initial = (principal_stresses[0] - principal_stresses[1]) / (principal_stresses[0] - principal_stresses[2])
    
    # 搜索最优摩擦系数
    friction_range = np.arange(friction_min, friction_max + friction_step, friction_step)
    mean_instability = np.zeros(len(friction_range))
    best_results = {}
    
    for i_friction, friction in enumerate(friction_range):
        tau_current = tau0.copy()
        
        # 迭代优化
        for i_iteration in range(N_iterations):
            # 计算主应力方向和形状比
            principal_stresses, principal_directions = stress_tensor_eigendecomposition(tau_current)
            R = (principal_stresses[0] - principal_stresses[1]) / (principal_stresses[0] - principal_stresses[2])
            
            # 使用不稳定性准则选择节面
            instability, strike, dip, rake = compute_instability_parameter(
                principal_directions, R, friction,
                strike1, dip1, rake1, strike2, dip2, rake2,
                return_fault_planes=True, signed_instability=False
            )
            
            if use_variable_shear:
                # 使用ILSI方法
                output = iterative_linear_si(
                    strike, dip, rake,
                    max_n_iterations=max_shear_iterations,
                    shear_update_atol=shear_tolerance,
                    return_eigen=False,
                    return_stats=False
                )
                tau_current = output["stress_tensor"]
            else:
                # 使用Michael方法
                tau_current = si_original.linear_stress_inversion(strike, dip, rake)
            
            # 归一化
            norm = np.linalg.norm(tau_current, 'fro')
            if norm > 0:
                tau_current /= norm
        
        # 记录结果
        mean_instability[i_friction] = np.mean(np.max(instability, axis=-1))
        best_results[friction] = {
            'tau': tau_current,
            'strike': strike,
            'dip': dip,
            'rake': rake,
            'instability': np.max(instability, axis=-1)
        }
    
    # 选择最优摩擦系数
    i_optimum = np.argmax(mean_instability)
    friction_optimum = friction_range[i_optimum]
    
    # 获取最优结果
    optimal_result = best_results[friction_optimum]
    tau_optimum = optimal_result['tau']
    strike = optimal_result['strike']
    dip = optimal_result['dip']
    rake = optimal_result['rake']
    instability = optimal_result['instability']
    
    # 计算最终形状比
    sigma = np.sort(np.linalg.eigvals(tau_optimum))
    shape_ratio = (sigma[0] - sigma[1]) / (sigma[0] - sigma[2])
    
    return tau_optimum, shape_ratio, strike, dip, rake, instability, friction_optimum