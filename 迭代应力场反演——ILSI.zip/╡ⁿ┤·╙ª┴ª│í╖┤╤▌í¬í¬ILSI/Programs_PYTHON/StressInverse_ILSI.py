#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
-------------------------------------------------------------------------
                                                                         
   program STRESSINVERSE - ILSI Version                                                
                                                                         
   使用ILSI (Iterative Linear Stress Inversion)方法的应力反演程序
   基于Beauce et al. 2022的迭代线性方法，允许剪切应力在不同断层上变化
                                                                         
   Modified to use ILSI instead of Michael method
   Version: 2.0 - ILSI                                             
   Last update: 2024                                              
                                                                         
-------------------------------------------------------------------------
"""

# Load a backend for plotting to png files
import matplotlib
matplotlib.use('Agg') 

import numpy as np
import matplotlib.pyplot as plt
import sys
import os

# Add current directory to path for imports
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# ------------------------------------------------
# reading input parameters
# ------------------------------------------------
import Input_parameters as ip

# ------------------------------------------------
# reading input data
# ------------------------------------------------
import read_mechanism as rm
strike_orig_1, dip_orig_1, rake_orig_1, strike_orig_2, dip_orig_2, rake_orig_2 = rm.read_mechanisms(ip.input_file)

print(f"读取到 {len(strike_orig_1)} 个震源机制")

# ------------------------------------------------
# 使用ILSI方法进行应力反演
# ------------------------------------------------
import stress_inversion_ilsi_module as si_ilsi

print("\n使用ILSI方法进行应力反演...")
tau_optimum, shape_ratio, strike, dip, rake, instability, friction = si_ilsi.stress_inversion_ilsi(
    strike_orig_1, dip_orig_1, rake_orig_1,
    strike_orig_2, dip_orig_2, rake_orig_2,
    ip.friction_min, ip.friction_max, ip.friction_step,
    ip.N_iterations, ip.N_realizations,
    use_variable_shear=True,  # ILSI特性：允许变剪切应力
    max_shear_iterations=300,
    shear_tolerance=1e-5
)

print(f"最优摩擦系数: {friction:.3f}")
print(f"形状比 R: {shape_ratio:.3f}")

# ------------------------------------------------
# optimum principal stress axes
# ------------------------------------------------
import azimuth_plunge as ap
diag_tensor, vector = np.linalg.eig(tau_optimum)

value = np.linalg.eigvals(np.diag(diag_tensor))
value_sorted = np.sort(value)
j = np.argsort(value)

sigma_vector_1_optimum = np.array(vector[:,j[0]])
sigma_vector_2_optimum = np.array(vector[:,j[1]])
sigma_vector_3_optimum = np.array(vector[:,j[2]])

direction_sigma_1, direction_sigma_2, direction_sigma_3 = ap.azimuth_plunge(tau_optimum)

print(f"\n主应力轴方向:")
print(f"σ1: 方位角 {direction_sigma_1[0]:.1f}°, 倾伏角 {direction_sigma_1[1]:.1f}°")
print(f"σ2: 方位角 {direction_sigma_2[0]:.1f}°, 倾伏角 {direction_sigma_2[1]:.1f}°")
print(f"σ3: 方位角 {direction_sigma_3[0]:.1f}°, 倾伏角 {direction_sigma_3[1]:.1f}°")

# ------------------------------------------------
# slip deviations
# ------------------------------------------------
import slip_deviation as sd
slip_deviation_1, slip_deviation_2 = sd.slip_deviation(tau_optimum, strike, dip, rake)
print(f"\n平均滑动偏差: {np.mean(np.minimum(slip_deviation_1, slip_deviation_2)):.1f}°")

# ------------------------------------------------
# principal focal mechanism
# ------------------------------------------------
import principal_mechanisms as pm
principal_strike, principal_dip, principal_rake = pm.principal_mechanisms(
    sigma_vector_1_optimum, sigma_vector_3_optimum, friction)

# ------------------------------------------------
# 噪声数据的不确定性分析 - 使用ILSI方法
# ------------------------------------------------
import noisy_mechanisms as nm
import statistics_stress_inversion_ilsi as ssi_ilsi

print(f"\n进行不确定性分析 ({ip.N_noise_realizations} 次噪声实现)...")

n_error_ = np.zeros(ip.N_noise_realizations)
u_error_ = np.zeros(ip.N_noise_realizations)

sigma_vector_1_statistics = np.zeros((3, ip.N_noise_realizations))
sigma_vector_2_statistics = np.zeros((3, ip.N_noise_realizations))
sigma_vector_3_statistics = np.zeros((3, ip.N_noise_realizations))
shape_ratio_statistics = np.zeros(ip.N_noise_realizations)

for i in range(ip.N_noise_realizations):
    if i % 20 == 0:
        print(f"  噪声实现 {i+1}/{ip.N_noise_realizations}")
    
    # 添加噪声到震源机制
    strike1, dip1, rake1, strike2, dip2, rake2, n_error, u_error = nm.noisy_mechanisms(
        ip.mean_deviation, strike_orig_1, dip_orig_1, rake_orig_1)
    
    n_error_[i] = np.mean(n_error)
    u_error_[i] = np.mean(u_error)
    
    # 使用ILSI方法进行统计反演
    sigma_vector_1, sigma_vector_2, sigma_vector_3, shape_ratio_noisy = ssi_ilsi.statistics_stress_inversion_ilsi(
        strike1, dip1, rake1, strike2, dip2, rake2,
        friction, ip.N_iterations, ip.N_realizations,
        use_variable_shear=True
    )
    
    sigma_vector_1_statistics[:,i] = sigma_vector_1
    sigma_vector_2_statistics[:,i] = sigma_vector_2
    sigma_vector_3_statistics[:,i] = sigma_vector_3
    shape_ratio_statistics[i] = shape_ratio_noisy

# ------------------------------------------------
# calculation of errors of the stress inversion
# ------------------------------------------------
sigma_1_error_statistics = np.zeros(ip.N_noise_realizations)
sigma_2_error_statistics = np.zeros(ip.N_noise_realizations)
sigma_3_error_statistics = np.zeros(ip.N_noise_realizations)
shape_ratio_error_statistics = np.zeros(ip.N_noise_realizations)

for i in range(ip.N_noise_realizations):
    dot1 = np.clip(np.abs(np.dot(sigma_vector_1_statistics[:,i], sigma_vector_1_optimum)), 0, 1)
    dot2 = np.clip(np.abs(np.dot(sigma_vector_2_statistics[:,i], sigma_vector_2_optimum)), 0, 1)
    dot3 = np.clip(np.abs(np.dot(sigma_vector_3_statistics[:,i], sigma_vector_3_optimum)), 0, 1)
    
    sigma_1_error_statistics[i] = np.arccos(dot1) * 180/np.pi
    sigma_2_error_statistics[i] = np.arccos(dot2) * 180/np.pi
    sigma_3_error_statistics[i] = np.arccos(dot3) * 180/np.pi
    shape_ratio_error_statistics[i] = 100 * np.abs((shape_ratio - shape_ratio_statistics[i])/shape_ratio)

# ------------------------------------------------
# confidence limits and error ranges
# ------------------------------------------------
mean_n_error = np.mean(n_error_)
mean_u_error = np.mean(u_error_)

# 主应力方向误差统计
max_sigma_1_error = np.max(sigma_1_error_statistics)
max_sigma_2_error = np.max(sigma_2_error_statistics)
max_sigma_3_error = np.max(sigma_3_error_statistics)

mean_sigma_1_error = np.mean(sigma_1_error_statistics)
mean_sigma_2_error = np.mean(sigma_2_error_statistics)
mean_sigma_3_error = np.mean(sigma_3_error_statistics)

# 形状比误差统计 - 计算详细的误差范围
shape_ratio_min = np.min(shape_ratio_statistics)
shape_ratio_max = np.max(shape_ratio_statistics)
shape_ratio_mean = np.mean(shape_ratio_statistics)
shape_ratio_std = np.std(shape_ratio_statistics)
shape_ratio_median = np.median(shape_ratio_statistics)

# 计算百分位数（95%置信区间）
shape_ratio_percentile_2_5 = np.percentile(shape_ratio_statistics, 2.5)
shape_ratio_percentile_97_5 = np.percentile(shape_ratio_statistics, 97.5)

# 计算相对误差统计
shape_ratio_error_mean = np.mean(shape_ratio_error_statistics)
shape_ratio_error_std = np.std(shape_ratio_error_statistics)
shape_ratio_error_min = np.min(shape_ratio_error_statistics)
shape_ratio_error_max = np.max(shape_ratio_error_statistics)

print(f"\n不确定性分析结果:")
print(f"主应力方向误差:")
print(f"  σ1: 平均 {mean_sigma_1_error:.1f}°, 最大 {max_sigma_1_error:.1f}°")
print(f"  σ2: 平均 {mean_sigma_2_error:.1f}°, 最大 {max_sigma_2_error:.1f}°")
print(f"  σ3: 平均 {mean_sigma_3_error:.1f}°, 最大 {max_sigma_3_error:.1f}°")

print(f"\n形状比R误差分析:")
print(f"  最优值: {shape_ratio:.3f}")
print(f"  噪声数据范围: {shape_ratio_min:.3f} - {shape_ratio_max:.3f}")
print(f"  平均值±标准差: {shape_ratio_mean:.3f} ± {shape_ratio_std:.3f}")
print(f"  中位数: {shape_ratio_median:.3f}")
print(f"  95%置信区间: [{shape_ratio_percentile_2_5:.3f}, {shape_ratio_percentile_97_5:.3f}]")
print(f"  相对误差: {shape_ratio_error_min:.1f}% - {shape_ratio_error_max:.1f}% (平均: {shape_ratio_error_mean:.1f}%)")

# ------------------------------------------------
# saving the results
# ------------------------------------------------
import scipy.io as sio

sigma_1 = {'azimuth': direction_sigma_1[0], 'plunge': direction_sigma_1[1]}
sigma_2 = {'azimuth': direction_sigma_2[0], 'plunge': direction_sigma_2[1]}
sigma_3 = {'azimuth': direction_sigma_3[0], 'plunge': direction_sigma_3[1]}

mechanisms = {'strike': strike, 'dip': dip, 'rake': rake}
principal_mechanisms = {'strike': principal_strike, 'dip': principal_dip, 'rake': principal_rake}

mechanisms_data = np.column_stack([strike, dip, rake])
principal_mechanisms_data = np.column_stack([principal_strike, principal_dip, principal_rake])

# 保存详细的误差统计信息
error_statistics = {
    'shape_ratio_range': [shape_ratio_min, shape_ratio_max],
    'shape_ratio_mean': shape_ratio_mean,
    'shape_ratio_std': shape_ratio_std,
    'shape_ratio_CI95': [shape_ratio_percentile_2_5, shape_ratio_percentile_97_5],
    'shape_ratio_error_range': [shape_ratio_error_min, shape_ratio_error_max],
    'shape_ratio_error_mean': shape_ratio_error_mean
}

data_matlab = {
    'sigma_1': sigma_1,
    'sigma_2': sigma_2,
    'sigma_3': sigma_3,
    'shape_ratio': shape_ratio,
    'shape_ratio_statistics': shape_ratio_statistics,  # 保存所有统计数据
    'error_statistics': error_statistics,  # 保存误差统计
    'mechanisms': mechanisms,
    'mechanisms_data': mechanisms_data,
    'friction': friction,
    'principal_mechanisms': principal_mechanisms,
    'method': 'ILSI'  # 标记使用的方法
}

# Save results
sio.savemat(ip.output_file + "_ILSI.mat", data_matlab)
np.savetxt(ip.output_file + "_ILSI.dat", mechanisms_data, fmt='%10.4f %10.4f %10.4f')
np.savetxt(ip.principal_mechanisms_file + "_ILSI.dat", principal_mechanisms_data, fmt='%10.4f %10.4f %10.4f')

# 保存误差统计到文本文件
with open(ip.output_file + "_ILSI_error_stats.txt", 'w') as f:
    f.write("ILSI应力反演不确定性分析结果\n")
    f.write("="*50 + "\n\n")
    f.write(f"输入噪声水平: {ip.mean_deviation}°\n")
    f.write(f"噪声实现次数: {ip.N_noise_realizations}\n\n")
    
    f.write("形状比R统计:\n")
    f.write(f"  最优值: {shape_ratio:.4f}\n")
    f.write(f"  范围: {shape_ratio_min:.4f} - {shape_ratio_max:.4f}\n")
    f.write(f"  平均值: {shape_ratio_mean:.4f}\n")
    f.write(f"  标准差: {shape_ratio_std:.4f}\n")
    f.write(f"  95%置信区间: [{shape_ratio_percentile_2_5:.4f}, {shape_ratio_percentile_97_5:.4f}]\n")
    f.write(f"  相对误差范围: {shape_ratio_error_min:.2f}% - {shape_ratio_error_max:.2f}%\n")
    f.write(f"  平均相对误差: {shape_ratio_error_mean:.2f}%\n")

print(f"\n误差统计已保存到: {ip.output_file}_ILSI_error_stats.txt")
print("\n结果已保存")

# ------------------------------------------------
# plotting the results
# ------------------------------------------------
print("\n生成图形...")

# P/T axes and the optimum principal stress axes
import plot_stress as plots
plots.plot_stress(tau_optimum, strike, dip, rake, ip.P_T_plot + "_ILSI")

# Mohr circle diagram
import plot_mohr as plotm
plotm.plot_mohr(tau_optimum, strike, dip, rake, principal_strike, principal_dip, principal_rake, ip.Mohr_plot + "_ILSI")

# Confidence limits of the principal stress axes
import plot_stress_axes as plotsa
plotsa.plot_stress_axes(sigma_vector_1_statistics, sigma_vector_2_statistics, sigma_vector_3_statistics, ip.stress_plot + "_ILSI")

# Histogram of shape ratio
pltHist, axH = plt.subplots(figsize=(8, 6))
n, bins, patches = axH.hist(x=shape_ratio_statistics, bins=ip.shape_ratio_axis,
                            color='#0504aa', alpha=0.7, edgecolor='black')
axH.axvline(shape_ratio, color='red', linestyle='--', linewidth=2,
            label=f'Optimal R={shape_ratio:.3f} (ILSI)')
axH.set_title('Shape Ratio Distribution - ILSI Method', fontsize=14)
axH.set_xlabel('Shape Ratio R')
axH.set_ylabel('Frequency')
axH.legend()
axH.grid(True, alpha=0.3)
plt.tight_layout()
pltHist.savefig(ip.shape_ratio_plot + '_ILSI.png', dpi=150)
plt.close(pltHist)

plt.suptitle(f'ILSI应力反演不确定性分析 (噪声水平: {ip.mean_deviation}°)', fontsize=16)
plt.tight_layout()
pltHist.savefig(ip.shape_ratio_plot + '_ILSI.png', dpi=600)

print("\n程序运行完成！(使用ILSI方法)")
print("=" * 60)